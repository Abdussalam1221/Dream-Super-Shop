<?php

$conn = mysqli_connect('localhost','root','','dream_super_shop') or die('connection failed');

?>