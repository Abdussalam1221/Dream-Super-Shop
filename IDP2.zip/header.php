<!DOCTYPE html>
<html>

<head>
   <meta charset='utf-8'>
   <meta http-equiv='X-UA-Compatible' content='IE=edge'>
   <title>Page Title</title>
   <link rel="stylesheet" href="fonts-6/css/all.css">
   <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
   <style>
      body {
         margin: 0;
         padding: 0;
         background-color: gainsboro;
      }

      /* Add your custom styles here */
      .header1 {
         display: flex;
         align-items: center;
         background-color: #F5F6F7;
      }

      .left-logo {
         width: 15%;
      }

      .left-logo img {
         width: 100%;
      }

      .right-profile {
         width: 10%;
         text-align: right;
         margin-right: 10px;
      }

      .right-profile img {
         width: 35px;
         height: 35px;
         border: 1px solid black;
         border-radius: 50%;
         padding: 2px;
      }

      .header-menu {
         width: 100%;
         margin: 0;
      }

      .header-menu ul {
         list-style-type: none;
         width: 100%;
         padding: 0;
         margin: auto;
         background-color: #333;
         align-items: center;
         justify-content: space-evenly;
         display: flex;
         font-size: 20px;
      }

      .header-menu li {
         display: inline;
      }

      .header-menu li a {
         display: inline-block;
         color: white;
         text-align: center;
         padding: 14px 16px;
         text-decoration: none;
         font-size: 22px;
      }

      .search-bar {
         width: 100%;
         padding: 10px;
         margin: auto;
         padding-left: 20%;
         background-color: #F5F6F7;
      }

      .search-bar input[type="text"] {
         padding: 7px;
         width: 40%;
      }

      .search-bar button[type="submit"] {
         width: 10%;
         padding: 9px 10px;
         background-color: #333;
         color: white;
         border: none;
         cursor: pointer;
      }
   </style>
</head>

<body>
   <header>
      <div class="header1">
         <div class="left-logo">
            <!-- Insert your logo here -->
            <img src="logo.png" alt="Logo">
         </div>

         <nav class="header-menu">
            <!-- Insert your navigation menu here -->
            <ul>
               <li><a href="home.php">Home</a></li>
               <li><a href="shop.php">Shop</a></li>
               <li><a href="cart.php">Cart</a></li>
               <li><a href="profile.php">Profile</a></li>
               <li><a href="contact.php">Contacts</a></li>
               <li><a href="return.php">Return</a></li>
               <li><a href="faqs.php">FAQs</a></li>
            </ul>
         </nav>

         <div class="right-profile">
            <!-- Insert your profile icon here -->
            <img src="uploaded_img\profile-icon.png" alt="Profile Icon">
         </div>
      </div>

      <div class="search-bar">
         <!-- Insert your search bar here fa-beat -->
         <i class="fa-regular fa-magnifying-glass"></i>
         <input type="text" placeholder="Search Product">
         <button type="submit">Search</button>
      </div>

   </header>
</body>

</html>